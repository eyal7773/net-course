import { Component } from "@angular/core";

@Component({
    selector:'app-manual-component',
    template:`<h1>this is manual-component</h1>`,
    
})
export class ManualComponent {

}