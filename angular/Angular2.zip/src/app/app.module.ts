import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ManualComponent } from './manual-component/manual-component';
import { MyFirstComponent } from './my-first/my-first.component';
import { My2Component } from './my2/my2.component';
import { My3Component } from './my3/my3.component';
import { My4Component } from './my4/my4.component';

@NgModule({
  declarations: [
    AppComponent,
    MyFirstComponent,
    My2Component,
    My3Component,
    ManualComponent,
    My4Component
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
