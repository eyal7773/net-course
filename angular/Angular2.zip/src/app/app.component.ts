import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'Angular2';
    myName = 'Eyal';
    age:number = 41;

    candy = { 
      color: 'yellow',
      taste: 'sweet',
    };

    imageSrc:string = 'https://images.unsplash.com/photo-1645902718013-370a382f14e9?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80';


    constructor() {
      this.age = 45;
    }

    getHairColor(color:string) {
      return "*" + color + "*";
    }


}
