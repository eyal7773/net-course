import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my2',
  templateUrl: './my2.component.html',
  styleUrls: ['./my2.component.css']
})                      // extends
export class My2Component implements OnInit {

  constructor() { }
  
  ngOnInit(): void {
    
  }

 

}
