import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my3',
  templateUrl: './my3.component.html',
  styleUrls: ['./my3.component.css']
})
export class My3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
