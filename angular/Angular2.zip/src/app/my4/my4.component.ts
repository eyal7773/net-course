import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'other-my4',
  templateUrl: './my4.component.html',
  styleUrls: ['./my4.component.css']
})
export class My4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
