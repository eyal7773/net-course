import { ComponentFixture, TestBed } from '@angular/core/testing';

import { My4Component } from './my4.component';

describe('My4Component', () => {
  let component: My4Component;
  let fixture: ComponentFixture<My4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ My4Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(My4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
