import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IfWithTemplateComponent } from './if-with-template.component';

describe('IfWithTemplateComponent', () => {
  let component: IfWithTemplateComponent;
  let fixture: ComponentFixture<IfWithTemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IfWithTemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IfWithTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
