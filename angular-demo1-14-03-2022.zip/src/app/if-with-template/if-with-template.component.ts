import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-if-with-template',
  templateUrl: './if-with-template.component.html',
  styleUrls: ['./if-with-template.component.css']
})
export class IfWithTemplateComponent implements OnInit {

  show:boolean = false;
  constructor() { }

  ngOnInit(): void {
  }
  toggleShow() {
    this.show = !this.show;
  }

}
