import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MenuComponent } from './menu/menu.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { CopyrightComponent } from './copyright/copyright.component';
import { UserAuthModule } from './user-auth/user-auth.module';
import { SimpleButtonComponent } from './simple-button/simple-button.component';
import { ManyEventsComponent } from './many-events/many-events.component';
import { TempMeterComponent } from './temp-meter/temp-meter.component';
import { CounterComponent } from './counter/counter.component';
import { Copyright2Component } from './copyright2/copyright2.component';
import { AuthModule } from './auth/auth.module';
import { SimpleButton2Component } from './simple-button2/simple-button2.component';
import { MultipleEventsComponent } from './multiple-events/multiple-events.component';
import { TempratureComponent } from './temprature/temprature.component';
import { BindAttrComponent } from './bind-attr/bind-attr.component';
import { NgifSimpleComponent } from './ngif-simple/ngif-simple.component';
import { IfWithTemplateComponent } from './if-with-template/if-with-template.component';
import { SwitchComponent } from './switch/switch.component';
import { StylingComponent } from './styling/styling.component';

import { BasicFormComponent } from './basic-form/basic-form.component';
import { Counter2Component } from './counter2/counter2.component';
import { Bind2Component } from './bind2/bind2.component';
import { Ngif2Component } from './ngif2/ngif2.component';
import { Switch3Component } from './switch3/switch3.component';
import { For3Component } from './for3/for3.component';
import { FormsModule } from '@angular/forms';
import { MyFirstFormComponent } from './my-first-form/my-first-form.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    UserDetailsComponent,
    CopyrightComponent,
    SimpleButtonComponent,
    ManyEventsComponent,
    TempMeterComponent,
    CounterComponent,
    Copyright2Component,
    SimpleButton2Component,
    MultipleEventsComponent,
    TempratureComponent,
    BindAttrComponent,
    NgifSimpleComponent,
    IfWithTemplateComponent,
    SwitchComponent,
    StylingComponent,
    BasicFormComponent,
    Counter2Component,
    Bind2Component,
    Ngif2Component,
    Switch3Component,
    For3Component,
    MyFirstFormComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    UserAuthModule,
    AuthModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
