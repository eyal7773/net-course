import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-my-first-form',
  templateUrl: './my-first-form.component.html',
  styleUrls: ['./my-first-form.component.css']
})
export class MyFirstFormComponent implements OnInit {

  constructor() { }
  // candy:{candyName:string ,sweetnees:string, damage:string} = {candyName : '',sweetnees:'',damage:''};
  candy:any = {};
  ngOnInit(): void {
  }

  handleSubmit(formData:any) {
    console.log(formData);
    this.candy = formData;
  }
}
