import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for3',
  templateUrl: './for3.component.html',
  styleUrls: ['./for3.component.css']
})
export class For3Component implements OnInit {

 /*
    מהלך חיים של קומפוננטה 

    איתחול המשתנים
    קונסטרטוק
    ngOnInit

 */
  hobbies:string[] = [] ;

  some:any[] = [];
  constructor() {

    this.setHobbies();

    this.some.push({bzz:1, foo:2});
    this.some.push({bzz:1, foo:2});
    this.some.push({bzz:1, foo:2});
   }

  ngOnInit(): void {
  }

  setHobbies() {
    this.hobbies.push('רכיבה על סוסים');
    this.hobbies.push('לצייר');
    this.hobbies.push('לרכב על אופנוע');

  }



}
