import { Component, OnInit } from '@angular/core';

enum Animals {
  Cow = 'cow',
  Dog = 'dog',
  Cat = 'cat',
  Unicorn = 'unicorn'
}

@Component({
  selector: 'app-switch3',
  templateUrl: './switch3.component.html',
  styleUrls: ['./switch3.component.css']
})
export class Switch3Component implements OnInit {

  // מגדיר משתנה שבעצם מחזיק את האינאם
  MyAnimalEnum = Animals;
  // להגדיר משתנה שמחזיק את הטייפ של האינמ
  myEnum: typeof Animals = Animals;
  
  animal:string=''; // פרה, כלב, חתול
  
  constructor() {

    this.animal = Animals.Dog;
    

   }

  ngOnInit(): void {
  }



}
