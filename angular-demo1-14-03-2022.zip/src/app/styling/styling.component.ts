import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styling',
  template: `
 
        <h1> ng style</h1>
        <div [style.font-size]="isSpecial ? '40px' : '8px'">Font size depends on isSpecial</div>
          
        <div [ngStyle]="currentStyles">One More DIV</div>
        <div [class.wow]="true">WOW!</div>
        <div [ngClass]="myClasses">Amazing, but not WOW!</div>
          `,
    styles:[
      `
      .wow {
        text-align: center;
        font-family: 'Oswald', Helvetica, sans-serif;
        font-size: 80px;
        transform: skewY(-10deg);
        letter-spacing: 4px;
        word-spacing: -8px;
        color: tomato;
        text-shadow: 
          -1px -1px 0 firebrick,
          -2px -2px 0 firebrick,
          -3px -3px 0 firebrick,
          -4px -4px 0 firebrick,
          -5px -5px 0 firebrick,
          -6px -6px 0 firebrick,
          -7px -7px 0 firebrick,
          -8px -8px 0 firebrick,
          -30px 20px 40px dimgrey
      }
      .amazing {
        text-align: center;
        color: white;
        text-transform: uppercase;
        padding: 1px;
        font-family: 'Raleway', cursive;
        font-weight: 100;
        position: relative;
        background: linear-gradient(to right, black, #eee, black);
      }
      `
    ]
})
export class StylingComponent implements OnInit {

  isSpecial:boolean = true;
  canSave:boolean = true;

  currentStyles = {};

  myClasses = {};

  constructor() { 
    this.setCurrentStyles();
    this.setMyClasses();
  }

  ngOnInit(): void {
  }

  setCurrentStyles(){
    this.currentStyles = {
      'font-style': this.canSave ? 'italic' : 'normal',
      'font-size': this.isSpecial ? '24px' : '12px'
    }
  }

  setMyClasses() {
    this.myClasses = {
      wow:false,
      amazing:true,
    }
  }

}
