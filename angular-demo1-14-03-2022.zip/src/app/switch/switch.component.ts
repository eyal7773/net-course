import { Component, OnInit } from '@angular/core';

// enum Color {
//   Red = 'red',
//   Blue = 'blue'
// }

@Component({
  selector: 'app-switch',
  templateUrl: './switch.component.html',
  styleUrls: ['./switch.component.css']
})
export class SwitchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  color:string ='';


}
