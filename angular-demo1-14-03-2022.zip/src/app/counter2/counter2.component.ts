import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-counter2',
  templateUrl: './counter2.component.html',
  styleUrls: ['./counter2.component.css']
})
export class Counter2Component implements OnInit {

  constructor() { }

  counter:number = 0;

  ngOnInit(): void {
  }

  handleClick(option:string) : void {
    if (option === '+') {
      this.counter++;  
    } else  {
      this.counter--;
    }
    
  }

  onPlus() :void {
    this.counter++;
  }

  onMinus():void  {
    this.counter--;
  }

}
