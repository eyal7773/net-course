import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BindAttrComponent } from './bind-attr.component';

describe('BindAttrComponent', () => {
  let component: BindAttrComponent;
  let fixture: ComponentFixture<BindAttrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BindAttrComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BindAttrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
