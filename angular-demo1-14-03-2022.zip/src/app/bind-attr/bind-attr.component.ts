import { Component, OnInit } from '@angular/core';

export interface Person {
  id:number,
  name:string,
  email:string
 }

@Component({
  selector: 'app-bind-attr',
  templateUrl: './bind-attr.component.html',
  styleUrls: ['./bind-attr.component.css']
})
export class BindAttrComponent implements OnInit {

  yoni:Person = {
    id:3,
    email: 'ljlkjljl@lkjlk.com',
    name:'Yoni'

  };

  constructor() { }

  ngOnInit(): void {
  }
  imageUrl:string = 'https://images.unsplash.com/photo-1640622304931-7f9e856f787b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80';

  postChanged:boolean = false;

  togglePostChanged():void {
    this.postChanged = !this.postChanged;
  }
}
