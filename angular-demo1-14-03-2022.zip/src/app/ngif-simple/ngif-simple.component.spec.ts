import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgifSimpleComponent } from './ngif-simple.component';

describe('NgifSimpleComponent', () => {
  let component: NgifSimpleComponent;
  let fixture: ComponentFixture<NgifSimpleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NgifSimpleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NgifSimpleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
