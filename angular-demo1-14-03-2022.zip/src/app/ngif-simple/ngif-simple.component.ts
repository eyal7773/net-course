import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngif-simple',
  template:`
  <h1>hi</h1>
  <button (click)="changeValue()">Change Value</button>
  <h1>{{text}}</h1>

  <hr>
  <h1 style="color:red">Works with double click !!</h1>
  <button (dblclick)="changeBoolValue()">changeBoolValue</button>
    <div *ngIf="value">
    <h1>{{text}}</h1>
 </div>

  `,
  styleUrls: ['./ngif-simple.component.css']
})
export class NgifSimpleComponent implements OnInit {

 
  text:string = 'Hello World!';

  value:boolean = true;


  constructor() { }

  ngOnInit(): void {
  }

  changeValue() {
    this.text = "Goodbye";
 }

 changeBoolValue() {
   this.value = !this.value;
 }

}
