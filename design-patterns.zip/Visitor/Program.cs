﻿using System;

namespace Visitor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Visitor Pattern Example!");

            Dog dog = new Dog();
            Cat cat = new Cat();

            IVetVisitor visitor = new VetVisitor();

            dog.Accept(visitor);
            cat.Accept(visitor);
        }
    }
    public interface IAnimalVisitable
    {
        void Accept(IVetVisitor visitor);
    }
    public abstract class Animal : IAnimalVisitable
    {
        public abstract void Accept(IVetVisitor visitor);
    }
    public class Dog : Animal
    {
        public override void Accept(IVetVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
    public class Cat : Animal
    {
        public override void Accept(IVetVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
    public interface IVetVisitor
    {
        void Visit(Dog dog);
        void Visit(Cat cat);
    }
    public class VetVisitor : IVetVisitor
    {
        public void Visit(Dog dog)
        {
            Console.WriteLine("Giving medicine...");
            Console.WriteLine("Brushing hair...");
            Console.WriteLine("Removing fleas...");
            Console.WriteLine("Performing medical inspection...");
        }
        public void Visit(Cat cat)
        {
            Console.WriteLine("Giving vitamins...");
            Console.WriteLine("Checking genitals...");
            Console.WriteLine("Checking nails...");
            Console.WriteLine("Performing medical inspection...");
        }
    }
}
